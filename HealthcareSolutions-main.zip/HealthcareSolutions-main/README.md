# HealthcareSolutions
The intent of this repository is to provide a centralized location for code, processes, and policies related to successful implementations of Eggplant Functional and Eggplant Manager in the healthcare.
Please find ongoing policies in the Wiki section.
Scripts and snippets will be housed in the code section.
###IMPORTANT: ANY IMAGES CAPTURED FROM EPIC, CERNER, ALLSCRIPTS, OR OTHER EMR SYSTEMS MUST BE HANDLED AS PROPRIETARY INFORMATION AND CANNOT BE DISTRIBUTED TO EMPLOYEES OR CUSTOMERS OUTSIDE THE US. IMAGES ARE ADDITIONALLY RESTRICTED TO CUSTOMERS WHO ARE LICENSED FOR THE PARTICULAR EMR.###

